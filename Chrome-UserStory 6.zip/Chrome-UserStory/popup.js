document.addEventListener('DOMContentLoaded', function() {
  console.log('Popup DOM loaded');
  
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('date').value = today;
  
  // Test Settings Toggle
  const testSettingsToggle = document.getElementById('testSettingsToggle');
  const testSettingsContent = document.getElementById('testSettingsContent');
  
  testSettingsToggle.addEventListener('click', function() {
    testSettingsToggle.classList.toggle('collapsed');
    testSettingsContent.classList.toggle('collapsed');
  });
  
  // Clean Button
  document.getElementById('cleanButton').addEventListener('click', function() {
    document.getElementById('description').value = '';
    updatePreview();
  });
  
  // Add event listeners for all inputs including test checkboxes
  document.querySelectorAll('input, select, textarea').forEach(element => {
    element.addEventListener('input', updatePreview);
  });
  
  document.getElementById('userStoryForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const userData = {
      firstName: document.getElementById('firstName').value,
      lastName: document.getElementById('lastName').value,
      email: document.getElementById('email').value
    };
    chrome.storage.local.set({ userData: userData });
    
    const previewContent = document.getElementById('previewContent').textContent;
    navigator.clipboard.writeText(previewContent).then(() => {
      alert('Text wurde in die Zwischenablage kopiert!');
    });
  });

  document.getElementById('refreshButton').addEventListener('click', function() {
    this.style.transform = 'rotate(360deg)';
    
    requestWorkItemInfo();
    
    setTimeout(() => {
      this.style.transform = '';
    }, 1000);
  });

  requestWorkItemInfo();
});

function requestWorkItemInfo() {
  console.log('Requesting work item info...');
  chrome.runtime.sendMessage({ action: "getWorkItemInfo" }, function(response) {
    console.log('Received work item info:', response);
    if (response) {
      setWorkItemInfo(response);
      if (response.userInfo) {
        document.getElementById('firstName').value = response.userInfo.firstName;
        document.getElementById('lastName').value = response.userInfo.lastName;
        document.getElementById('email').value = response.userInfo.email;
        chrome.storage.local.set({ userData: response.userInfo });
      } else {
        chrome.storage.local.get(['userData'], function(result) {
          if (result.userData) {
            document.getElementById('firstName').value = result.userData.firstName;
            document.getElementById('lastName').value = result.userData.lastName;
            document.getElementById('email').value = result.userData.email;
          }
        });
      }
    }
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Popup received message:', request);
  if (request.action === "updateWorkItemInfo" && request.workItemInfo) {
    console.log('Updating work item info:', request.workItemInfo);
    setWorkItemInfo(request.workItemInfo);
    
    if (request.workItemInfo.userInfo) {
      document.getElementById('firstName').value = request.workItemInfo.userInfo.firstName;
      document.getElementById('lastName').value = request.workItemInfo.userInfo.lastName;
      document.getElementById('email').value = request.workItemInfo.userInfo.email;
      chrome.storage.local.set({ userData: request.workItemInfo.userInfo });
    }
    
    updatePreview();
  }
});

function updatePreview() {
  const text = generateText();
  const previewContent = document.getElementById('previewContent');
  previewContent.textContent = text;
}

function generateText() {
  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const email = document.getElementById('email').value;
  const date = document.getElementById('date').value;
  const status = document.getElementById('status').value;
  const description = document.getElementById('description').value;
  
  let text = `${firstName} ${lastName}\n${email}\n${date}\n\n`;
  
  if (window.currentWorkItem) {
    text += `Work Item - ${window.currentWorkItem.workItemType} ${window.currentWorkItem.workItemId}: <a href="${window.currentWorkItem.workItemUrl}">${window.currentWorkItem.title}</a>\n\n`;
  }
  
  text += `${status}\nComment: ${description}\n\n`;
  
  return text;
}

function setWorkItemInfo(workItemInfo) {
  console.log('Setting work item info:', workItemInfo);
  const workItemInfoElement = document.getElementById('workItemInfo');
  
  // Create a span element for the work item info
  const workItemSpan = document.createElement('span');
  workItemSpan.textContent = `${workItemInfo.workItemType} ${workItemInfo.workItemId} - ${workItemInfo.title}`;
  workItemSpan.style.cursor = 'pointer';
  workItemSpan.title = 'Click to copy to clipboard';
  
  // Add click handler to copy to clipboard
  workItemSpan.addEventListener('click', () => {
    navigator.clipboard.writeText(`${workItemInfo.workItemType} ${workItemInfo.workItemId} - ${workItemInfo.title}`).then(() => {
      // Visual feedback for copy
      const originalColor = workItemSpan.style.color;
      workItemSpan.style.color = '#0078d4';
      setTimeout(() => {
        workItemSpan.style.color = originalColor;
      }, 200);
    });
  });
  
  workItemInfoElement.innerHTML = '';
  workItemInfoElement.appendChild(workItemSpan);
  window.currentWorkItem = workItemInfo;
  updatePreview();
}
