let currentTabId = null;

chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension wurde installiert');
});

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received message:', request);
  
  if (request.action === "getWorkItemInfo") {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const activeTab = tabs[0];
      if (activeTab && activeTab.url.includes('dev.azure.com')) {
        chrome.tabs.sendMessage(activeTab.id, { action: "getWorkItemInfo" }, (response) => {
          console.log('Content script response:', response);
          sendResponse(response);
        });
      }
    });
    return true;
  }
  
  if (request.action === "urlChanged") {
    console.log('URL changed, updating side panel');
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const activeTab = tabs[0];
      if (activeTab && activeTab.url.includes('dev.azure.com')) {
        chrome.tabs.sendMessage(activeTab.id, { action: "getWorkItemInfo" }, (response) => {
          if (response) {
            chrome.runtime.sendMessage({ 
              action: "updateWorkItemInfo", 
              workItemInfo: response 
            });
          }
        });
      }
    });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'someAction') {
    sendResponse({ status: 'success' });
  }
  return true;
}); 
