// Speichere die aktuelle Tab-Information
let currentTabId = null;

// Background Service Worker
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension wurde installiert');
});

// Öffne das Sidepanel wenn auf das Icon geklickt wird
chrome.action.onClicked.addListener((tab) => {
  // Öffne das Sidepanel
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// Vermittle die Kommunikation zwischen Sidepanel und Content Script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received message:', request);
  
  if (request.action === "getWorkItemInfo") {
    // Hole den aktiven Tab
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const activeTab = tabs[0];
      if (activeTab && activeTab.url.includes('dev.azure.com')) {
        // Leite die Anfrage an den Content Script weiter
        chrome.tabs.sendMessage(activeTab.id, { action: "getWorkItemInfo" }, (response) => {
          console.log('Content script response:', response);
          sendResponse(response);
        });
      }
    });
    return true; // Wichtig für asynchrone Antwort
  }
  
  // Behandle URL-Änderungen
  if (request.action === "urlChanged") {
    console.log('URL changed, updating side panel');
    // Hole den aktiven Tab
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const activeTab = tabs[0];
      if (activeTab && activeTab.url.includes('dev.azure.com')) {
        // Hole die neuen Work Item Informationen
        chrome.tabs.sendMessage(activeTab.id, { action: "getWorkItemInfo" }, (response) => {
          if (response) {
            // Sende die neuen Informationen an das Sidepanel
            chrome.runtime.sendMessage({ 
              action: "updateWorkItemInfo", 
              workItemInfo: response 
            });
          }
        });
      }
    });
  }
});

// Hier können Sie weitere Hintergrundprozesse implementieren
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'someAction') {
    // Implementieren Sie hier Ihre Logik
    sendResponse({ status: 'success' });
  }
  return true;
}); 
