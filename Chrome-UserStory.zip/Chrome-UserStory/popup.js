document.addEventListener('DOMContentLoaded', function() {
  console.log('Popup DOM loaded');
  
  // Setze das aktuelle Datum
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('date').value = today;
  
  // Event Listener für Formular-Änderungen
  document.querySelectorAll('input, select, textarea').forEach(element => {
    element.addEventListener('input', updatePreview);
  });
  
  // Event Listener für Formular-Submit
  document.getElementById('userStoryForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Speichere die Benutzerdaten
    const userData = {
      firstName: document.getElementById('firstName').value,
      lastName: document.getElementById('lastName').value,
      email: document.getElementById('email').value
    };
    chrome.storage.local.set({ userData: userData });
    
    // Kopiere den generierten Text in die Zwischenablage
    const previewContent = document.getElementById('previewContent').textContent;
    navigator.clipboard.writeText(previewContent).then(() => {
      alert('Text wurde in die Zwischenablage kopiert!');
    });
  });

  // Event Listener für Refresh-Button
  document.getElementById('refreshButton').addEventListener('click', function() {
    // Füge eine Rotation-Animation hinzu
    this.style.transform = 'rotate(360deg)';
    
    // Hole neue Work Item Informationen
    requestWorkItemInfo();
    
    // Entferne die Animation nach 1 Sekunde
    setTimeout(() => {
      this.style.transform = '';
    }, 1000);
  });

  // Initial hole Work Item Informationen
  requestWorkItemInfo();
});

// Funktion zum Anfordern der Work Item Informationen
function requestWorkItemInfo() {
  console.log('Requesting work item info...');
  chrome.runtime.sendMessage({ action: "getWorkItemInfo" }, function(response) {
    console.log('Received work item info:', response);
    if (response) {
      setWorkItemInfo(response);
      // Fülle die Benutzerfelder, wenn verfügbar
      if (response.userInfo) {
        document.getElementById('firstName').value = response.userInfo.firstName;
        document.getElementById('lastName').value = response.userInfo.lastName;
        document.getElementById('email').value = response.userInfo.email;
        // Speichere die Benutzerdaten
        chrome.storage.local.set({ userData: response.userInfo });
      } else {
        // Lade gespeicherte Benutzerdaten als Fallback
        chrome.storage.local.get(['userData'], function(result) {
          if (result.userData) {
            document.getElementById('firstName').value = result.userData.firstName;
            document.getElementById('lastName').value = result.userData.lastName;
            document.getElementById('email').value = result.userData.email;
          }
        });
      }
    }
  });
}

// Listener für Work Item Updates
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Popup received message:', request);
  if (request.action === "updateWorkItemInfo" && request.workItemInfo) {
    console.log('Updating work item info:', request.workItemInfo);
    setWorkItemInfo(request.workItemInfo);
    
    // Aktualisiere die Benutzerfelder, wenn verfügbar
    if (request.workItemInfo.userInfo) {
      document.getElementById('firstName').value = request.workItemInfo.userInfo.firstName;
      document.getElementById('lastName').value = request.workItemInfo.userInfo.lastName;
      document.getElementById('email').value = request.workItemInfo.userInfo.email;
      // Speichere die neuen Benutzerdaten
      chrome.storage.local.set({ userData: request.workItemInfo.userInfo });
    }
    
    // Aktualisiere die Vorschau
    updatePreview();
  }
});

function updatePreview() {
  const text = generateText();
  const previewContent = document.getElementById('previewContent');
  previewContent.textContent = text;
}

function generateText() {
  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const email = document.getElementById('email').value;
  const date = document.getElementById('date').value;
  const status = document.getElementById('status').value;
  const description = document.getElementById('description').value;
  
  let text = `${firstName} ${lastName}\n${email}\n${date}\n\n`;
  
  if (window.currentWorkItem) {
    text += `Work Item: <a href="${window.currentWorkItem.workItemUrl}">${window.currentWorkItem.title}</a>\n\n`;
  }
  
  text += `${status}\nComment: ${description}`;
  
  return text;
}

function setWorkItemInfo(workItemInfo) {
  console.log('Setting work item info:', workItemInfo);
  const workItemInfoElement = document.getElementById('workItemInfo');
  workItemInfoElement.innerHTML = `<a href="${workItemInfo.workItemUrl}" target="_blank">${workItemInfo.title}</a>`;
  window.currentWorkItem = workItemInfo;
  updatePreview();
}
