# Chrome User Story Extension

Eine private Chrome Extension für persönliche Anpassungen.

## Installation

Da diese Extension nicht im Chrome Web Store veröffentlicht ist, können Sie sie wie folgt installieren:

1. Öffnen Sie Chrome und navigieren Sie zu `chrome://extensions/`
2. Aktivieren Sie den "Entwicklermodus" in der oberen rechten Ecke
3. Klicken Sie auf "Entpackte Extension laden"
4. Wählen Sie den Ordner aus, in dem sich diese Extension befindet

## Projektstruktur

- `manifest.json` - Konfigurationsdatei der Extension
- `popup.html` - Benutzeroberfläche der Extension
- `popup.js` - JavaScript für die Benutzeroberfläche
- `background.js` - Hintergrundprozesse
- `styles.css` - Styling der Extension
- `icons/` - Verzeichnis für die Extension-Icons

## Entwicklung

Um die Extension zu entwickeln:

1. Machen Sie Ihre Änderungen in den entsprechenden Dateien
2. Gehen Sie zu `chrome://extensions/`
3. Klicken Sie auf das Aktualisieren-Symbol der Extension
4. Ihre Änderungen werden sofort übernommen

## Hinweis

Diese Extension ist für den privaten Gebrauch bestimmt und nicht für die Veröffentlichung im Chrome Web Store vorgesehen. 
