function extractWorkItemInfo() {
    const url = window.location.href;
    console.log('Extracting info from URL:', url);

    const assignedToMatch = url.match(/AssignedTo=([^&]+)/);
    let userInfo = null;
    
    if (assignedToMatch) {
        console.log('Found AssignedTo match:', assignedToMatch[1]);
        const firstUser = assignedToMatch[1].split('%2C')[0];
        const fullName = decodeURIComponent(firstUser).toLowerCase();
        const nameParts = fullName.split('.');
        if (nameParts.length >= 2) {
            const firstName = nameParts[0].charAt(0).toUpperCase() + nameParts[0].slice(1);
            const lastName = nameParts[1].split('@')[0].charAt(0).toUpperCase() + nameParts[1].split('@')[0].slice(1);
            const email = firstName.toLowerCase() === 'andre' && lastName.toLowerCase() === 'sieger' 
                ? `${nameParts[0]}.${nameParts[1].split('@')[0]}@scheja-partners.de`
                : `${nameParts[0]}.${nameParts[1].split('@')[0]}@lcs.valantic.com`;
            
            userInfo = {
                firstName,
                lastName,
                email
            };
            console.log('Extracted user info:', userInfo);
        } else {
            console.log('Could not parse name parts from:', fullName);
        }
    } else {
        console.log('No AssignedTo parameter found in URL');
    }

    let workItemId = null;
    
    const workItemMatch = url.match(/workitem=(\d+)/);
    if (workItemMatch) {
        workItemId = workItemMatch[1];
        console.log('Found workItemId from workitem parameter:', workItemId);
    }
    
    if (!workItemId) {
        const editMatch = url.match(/\/edit\/(\d+)/);
        if (editMatch) {
            workItemId = editMatch[1];
            console.log('Found workItemId from edit path:', workItemId);
        }
    }

    if (workItemId) {
        const baseUrl = url.split('/_boards/')[0] || url.split('/_workitems/')[0];
        const workItemUrl = `${baseUrl}/_workitems/edit/${workItemId}`;
        console.log('Generated workItemUrl:', workItemUrl);

        let title = null;
        const selectors = [
            '.bolt-textfield-input[aria-label="Title field"]',
            '.work-item-title',
            '[data-test-id="work-item-title"]',
            '.witform-title',
            '.work-item-form-title',
            'h1.title'
        ];

        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element) {
                title = element.value || element.textContent.trim();
                console.log('Found title using selector:', selector, title);
                break;
            }
        }

        if (!title) {
            title = `Work Item ${workItemId}`;
            console.log('Using fallback title:', title);
        }

        return {
            workItemId,
            workItemUrl,
            title,
            userInfo
        };
    }

    console.log('No workItemId found in URL');
    return null;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Content script received message:', request);
    
    if (request.action === "getWorkItemInfo") {
        const workItemInfo = extractWorkItemInfo();
        console.log('Sending workItemInfo:', workItemInfo);
        sendResponse(workItemInfo);
    }
    return true;
});

let lastUrl = location.href;
let observer = null;

function setupUrlObserver() {
    if (observer) {
        observer.disconnect();
    }

    observer = new MutationObserver(() => {
        const currentUrl = location.href;
        if (currentUrl !== lastUrl) {
            console.log('URL changed from:', lastUrl, 'to:', currentUrl);
            lastUrl = currentUrl;
            
            setTimeout(() => {
                const workItemInfo = extractWorkItemInfo();
                if (workItemInfo) {
                    console.log('Sending updated workItemInfo:', workItemInfo);
                    chrome.runtime.sendMessage({ 
                        action: "updateWorkItemInfo", 
                        workItemInfo: workItemInfo 
                    });
                }
            }, 500);
        }
    });

    observer.observe(document, { 
        subtree: true, 
        childList: true,
        characterData: true
    });
}

setupUrlObserver();

console.log('Content script loaded on:', window.location.href);
const initialWorkItemInfo = extractWorkItemInfo();
if (initialWorkItemInfo) {
    console.log('Sending initial workItemInfo:', initialWorkItemInfo);
    chrome.runtime.sendMessage({ 
        action: "updateWorkItemInfo", 
        workItemInfo: initialWorkItemInfo 
    });
} 
